package kr.smhrd.myapp;


import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import kr.smhrd.domain.Board;
import kr.smhrd.mapper.BoardMapper;

@Controller // 전처리 기능
public class BoardController{
	// 게시판 리스트 요청을 받기 : http://127.0.0.1:8081/myapp/boardList.do
	@Autowired
	private BoardMapper mapper; // SqlSessionFactorybean implements BoardMapper
		
	@RequestMapping("/boardList.do")
	public String boardList(Model model) {		
		List<Board>list = mapper.selectAll();
		model.addAttribute("list", list);		
		// 어떤 JSP가 처리할건지를 리턴하기
		return "boardList";	//JSTL+EL로 바꾸기	
	}
	@GetMapping("/boardForm.do")
	public String boardForm() {		
		return "boardForm"; // WEB-INF/views/boardForm.jsp//JSTL+EL로 바꾸기	
	}
	@PostMapping("/boardInsert.do")
	public String boardInsert(Board vo) { // title, content, writer
		// 파라메터 수집(vo,dto)
		mapper.boardInsert(vo);//등록완료		
		return "redirect:/boardList.do"; // controller로 가려면 앞에 redirect를 써줘야함

				
	}
	
	@GetMapping("/boardContent.do")
	//(@RequestParam("idx")int idx)
	public String boardContent(int idx, Model model) { // /2
		Board vo = mapper.boardContent(idx);
		model.addAttribute("vo", vo);
		//board를 jsp로 넘겨서 상세페이지를 만들어야함-> 그전에 객체 바인딩 해줘야함->메모리필요(request or session객체 필요)
		return "boardContent"; // /WEB-INF/views/boardContent.jsp//JSTL+EL로 바꾸기
	}
	@GetMapping("/boardDelete.do/{idx}") // {idx:1,"aaa":"zzz"}
	public String boardDelete(@PathVariable int idx) {
		mapper.boardDelete(idx);//삭제성공
		return "redirect:/boardList.do";
	}
	@RequestMapping(value="/boardUpdate.do/{idx}",method = RequestMethod.GET)
	public String boardUpdateGet(@PathVariable int idx, Model model) {
		Board vo = mapper.boardContent(idx);
		model.addAttribute("vo",vo);
		return "boardUpdate"; //boardUpdate.jsp를 이제 만들자//JSTL+EL로 바꾸기
		
	}
	@RequestMapping(value="/boardUpdate.do",method = RequestMethod.POST)
	public String boardUpdatePost(Board vo) {
		mapper.boardUpdate(vo);		
		return "redirect:/boardList.do"; //boardUpdate.jsp를 이제 만들자
	}
	
}
