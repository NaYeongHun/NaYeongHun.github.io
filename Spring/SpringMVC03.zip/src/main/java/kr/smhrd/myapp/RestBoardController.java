package kr.smhrd.myapp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import kr.smhrd.domain.Board;

import kr.smhrd.service.BoardService;
@RestController//  @ResponseBody //ajax통신 컨트롤러를 여기에 받아준다
public class RestBoardController {
   
    @Autowired
    private BoardService service; 
   
    @RequestMapping("/boardList.do")
	public List<Board> boardList() {
		List<Board> list = service.selectAll();
		// list --(jackson databin) ---> JSON(String)
		//[{	},{		},{		}]
			return list; //ajax()함수쪽으로 데이터를 전달		
	}
	
	@RequestMapping("/boardContentUpdate.do")
	public void boardContentUpdate(Board vo) {
		service.boardContentUpdate(vo);
		
	}
	@RequestMapping("/boardInsert.do")
	public void boardInsert(Board vo){
		service.boardInsert(vo);
	}
	@RequestMapping("/boardDelete.do")
	public void boardDelete(int idx){
		service.boardDelete(idx);
	}
	@RequestMapping("/boardUpdateTW.do")
	public void boardUpdateTW(Board vo) {
		service.boardUpdateTW(vo);
	}
}
