package kr.smhrd.myapp;


import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import kr.smhrd.domain.Board;
import kr.smhrd.domain.Member;
import kr.smhrd.mapper.BoardMapper;
import kr.smhrd.service.BoardService;

@Controller // 전처리 기능 // ajax통신이 아닌 다른 일반적인것은 여기서 처리해준다
public class BoardController{
		
	@Autowired
	BoardService service;// 사용자 요구에 대한 로직을 짜기 위한 곳
	
	@RequestMapping("/")
	public String main() {
		return "basic";
	}
	
	@RequestMapping("/login.do")
	public String login(Member vo, HttpSession session) {
		// 회원 인증처리 (세션)
		Member mvo = service.login(vo);
		//회원 인증 여부를 체크
		if (mvo!=null) {// 성공 -> 객체바인딩(중요)
			session.setAttribute("mvo", mvo); //JS -> ${mvo}이 값이 있으면 회원인증성공-> ${mvo.memUser} 로그인된 사람 이름 출력
		}		
		return "redirect:/";
	}
	@RequestMapping("/logout.do")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}
}	
