create table board(
  idx int not null auto_increment, 
  title varchar(100) not null,
  content varchar(2000) not null,
  memID varchar(20) not null,
  writer varchar(20) not null,
  indate datetime default now(), -- sysdate
  count int default 0,
  primary key(idx)
);
drop table board;

insert into board(title, content, writer)
values('스프링게시판','스프링게시판','관리자');

insert into board(title, content, writer)
values('스프링게시판','스프링게시판','나영훈');

select *from board;

create table member(
  memId varchar(20) not null,
  memPwd varchar(20) not null,
  memUser varchar(20) not null,
  primary key(memId)
);

drop table member;

insert into member values('smhrd01','smhrd01','나영훈');
insert into member values('smhrd02','smhrd02','박매일');
insert into member values('smhrd03','smhrd03','김운비');

select * from member;



