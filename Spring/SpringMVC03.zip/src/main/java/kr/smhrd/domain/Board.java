package kr.smhrd.domain;

import lombok.Data;

@Data // lombok API가 있어야 임포트됨 -> 이클립스에게 setter와 getter를 만들어주라는 요청
public class Board {
	// property(속성)
	private int idx;//번호
	private String title;// 제목
	private String content;// 내용
	private String memId; // 작성자 아이디
	private String Writer;//작성자
	private String indate;// 작성일
	private int count;// 조회수
	// setter, getter method를 자동으로 만들어주는 API(lombok:롬복)	
}
