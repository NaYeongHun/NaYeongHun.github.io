package kr.smhrd.domain;

import java.util.List;

import lombok.Data;

@Data
public class Member {
	private String memId; // 아이디(PK)
	private String memPwd; // 비밀번호
	private String memUser; // 이름
	
	private List<String> memHobby;
}
