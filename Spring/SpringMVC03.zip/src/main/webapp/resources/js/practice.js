	function getContextPath(){
    	var hostIndex=location.href.indexOf(location.host) + location.host.length;
   		var contextPath=location.href.substring(hostIndex,location.href.indexOf("/",hostIndex+1));
    	return contextPath;
  }
	  function loadList(){
	   //게시판 리스트를 서버에 요청하기(boardList.do)
	    $.ajax({
	      url : getContextPath()+"/boardList.do", 
	      type: "get",
	      //data : {    },
	      dataType : "json",
	      success : htmlView,
	      error : function(){ alert("error"); }
	    });
	  }
	  
	 
	  function goUpdate(idx) {
		var title=$("#t"+idx).text(); // 제목 잠시 대피
		var tInput="<input type='text' id='nt"+idx+"' class='form-control' value='"+title+"'>";
		$("#t"+idx).html(tInput);

		var writer=$("#w"+idx).text(); // 작성자 잠시 대피
		var wInput="<input type='text' id='nw"+idx+"' class='form-control' value='"+writer+"'>";
		$("#w"+idx).html(wInput);

		var newBtn="<button class='btn btn-info btn-sm' onclick='goUpdate1("+idx+")'>수정하기</button>";
		$("#u"+idx).html(newBtn);
	 }
	 function goUpdate1(idx) { //번호(idx), 제목(?), 작성자(?)
		var title=$("#nt"+idx).val();
		var writer=$("#nw"+idx).val();
		$.ajax({
			  url : getContextPath()+"/boardUpdateTW.do",         
			  type : "post",
		   data : { "idx":idx,"title":title,"writer":writer},          
		   success : loadList,
		   error : function(){ alert("error");  }
		  });
	 }
	  function goDel(idx){
		$.ajax({
			url : getContextPath()+"/boardDelete.do",
			type : "get",
			data :{"idx":idx},
			success : loadList,
			error : function(){alert("error");}

		});

	  }
	  
	  function goView(){
		if($("#wform").css("display")=="none"){
			//$("#wform").css("display","block"); //OPEN
			$("#wform").slideDown();
			
	   }else{
			//$("#wform").css("display","none"); //CLOSE
			$("#wform").slideUp();
	   }
	}
	  
	  function updateFn(idx){ // idx(번호), content(내용)
		  var content = $("#c"+idx).val();
	  		$.ajax({
	  			url : getContextPath()+"/boardContentUpdate.do",
	  			type : "post",
	  			data : {"idx":idx, "content":content},
	  			success : loadList,
	  			error : function(){	alert("error");}	  			
	  		})
	  }
	  function closeFn(idx){
		  $("#cv"+idx).css("display","none"); //close
	  }
	  function contentView(idx){
		  if($("#cv"+idx).css("display")=="none"){
		  	$("#cv"+idx).css("display","table-row"); //open
		  }else{
		 	$("#cv"+idx).css("display","none"); // close			  
		}	
	  }
	   function goInsert(){ // form(id='frm')에 있는 파라메터 3개를 가져오기
		  // 직렬화(title=XXX&content=XXX&writer=XXX) 시켜서 3개 가져오면 편하다
		  var fData=$("#frm").serialize();
		  $.ajax({
			url : getContextPath()+"/boardInsert.do",
			type : "post",
			data : fData,
			success : loadList,
			error : function(){ alert("error"); }
		  });
		  
		  // 취소 버튼을 강제로 클릭하기
		  $("#init").trigger("click");
			
		  $("#wform").css("display","none");
	  }		  
	  	  
		  function logout(){
		 	 location.href =getContextPath()+"/logout.do";
		  }