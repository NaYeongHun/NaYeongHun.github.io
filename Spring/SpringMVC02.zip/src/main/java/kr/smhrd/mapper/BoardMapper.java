package kr.smhrd.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Update;

import kr.smhrd.domain.Board;

// JDBC(Java + SQL)-> DB Framework(MyBatis API)-Mapping
//1. 생산성이 떨어진다.(개발속도가 늦다)
//2. 유지보수가 어렵다.
// DB Framework(MyBatis API= mybatis.org) 
//1. Java SQL Mapping Framework
//2. Java소스코드와  SQL쿼리문을 분리해서 개발
// Mapper Interface
// 1. Mapper interface + Mapper XML File(SQL) ->복잡한 쿼리 용이
// 2. Mapper interface + @(애노테이션) , File(X)
public interface BoardMapper {
	public List<Board> selectAll();
	public void boardInsert(Board vo); // insert SQL~
	public Board boardContent(int idx); // select SQL~
	
	@Delete("delete from board where idx=#{idx}")
	public void boardDelete(int idx); // delete SQL~
	public void boardUpdate(Board vo); // update SQL~
	
	@Update("update board set content=#{content} where idx=#{idx}")
	public void boardContentUpdate(Board vo);
	
	public void boardUpdateTW(Board vo); //updateSQL~
}